with open("file.txt", "r") as fa:
    stra = fa.read()


print(fa.closed)
