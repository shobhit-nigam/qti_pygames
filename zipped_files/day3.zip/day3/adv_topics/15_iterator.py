listx = [11, 22, 33, 44, 55]

obji = iter(listx)

print(next(obji))

print(next(obji))
