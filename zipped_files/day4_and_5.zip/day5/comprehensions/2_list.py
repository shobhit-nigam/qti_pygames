lista = [11, 13, 6, 8, 4, 19, 4, 20, 7]
listb = [14, 18, 4, 2, 7, 16, 9, 17, 3]

listnew = [val for val in lista if val%2==0 ]

print(listnew)
