varx =  100
vary = "hello"

print(vars())
print("---------")
print(dir())
