"""python app for defining colours
it has three functions & a list which can be used:-"""

__name__ = "colourful library"

def blue():
    print("cool blue")

def yellow():
    print("bright yellow")

def green():
    print("green needs:")
    blue()
    yellow()

listx = ['aa', 'vv', 'rr', 'ee', 'cc']
