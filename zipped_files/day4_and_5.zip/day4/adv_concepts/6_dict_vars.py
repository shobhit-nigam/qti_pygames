start = len(dir())

varx =  100
vary = "hello"

def funcx():
    la = 100
    lb = 200

class Sample:
    pass

print(f"objects created in the code = {dir()[start:]}")
