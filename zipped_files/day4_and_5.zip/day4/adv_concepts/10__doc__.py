"application to fight wars"

import colours

def funcx():
    "function to launch missiles"
    print("in funcx")

class Sample:
    """a non violent class used
    as a pacifist"""

    data = 10

print(f"__doc__ = {__doc__}")
print(f"colours.__doc__ = {colours.__doc__}")
