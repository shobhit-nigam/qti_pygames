"application to fight wars"

datax = 100
datay = 200

def funcx():
    "function to launch missiles"
    print("in funcx")
    la = 11
    lb = 22

class Sample:
    """a non violent class used
    as a pacifist"""

    data = 10

print(globals())
