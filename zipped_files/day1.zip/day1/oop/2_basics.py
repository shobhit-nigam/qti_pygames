class Bank:
    pass

# pseudo code
class Employee:
    id = 0
    name = ""
    salary = 0
    department = None

    def tax():
        # calculate tax based on salary
        tax_to_be_paid = salary * 0.25
        return tax_to_be_paid
