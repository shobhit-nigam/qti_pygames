varx = 10
series = "house of dragons"

print(f"type of varx = {type(varx)}")
print(f"type of series = {type(series)}")

def funcx():
    # some function
    pass

print(f"type of funcx = {type(funcx)}")
