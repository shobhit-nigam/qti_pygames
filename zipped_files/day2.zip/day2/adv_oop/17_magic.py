val = 100
print(val + 10)
print(val.__add__(10))
