lista = [11, 22, 33, 44]
listb = [88, 77, 66, 55]
seta = {'aa', 'bb', 'cc', 'dd'}
setb = {'aa', 'tt', 'ww', 'bb'}
stra = "hello"
strb = "hi"

print(lista+listb)
print(seta - setb)
print(stra + strb)
print(stra+strb*5)
# error
# print(seta+setb)
